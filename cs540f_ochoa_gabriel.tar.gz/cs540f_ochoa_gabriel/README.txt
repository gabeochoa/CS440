Gabriel Ochoa
B00386228

For problem one, I had some trouble getting the void test to work. 
I have commented out the third test and my void function declaration. 
I tried to do the multiple param pack way and couldnt get it working on time, 
i have commented it out below the working copy

For the second problem,
I couldnt figure out how to stop multiple inheritance from counting twice. 