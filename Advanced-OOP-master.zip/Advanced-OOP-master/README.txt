Kyle Goodwill
kgoodwi2@binghamton.edu
B00309119

It works without being converted to a macro, but when I convert it, it won't compile now.
I don't what is wrong with it.
Sorry :(