Gabriel Ochoa
gochoa1@binghamton.edu
B00386228

SmartPtr:
	Passes all tests

Function:    
    Passes all tests
